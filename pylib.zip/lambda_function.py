import logging
import os

from pyiceberg.catalog import load_catalog

logger = logging.getLogger()

# Get Environment Variables
S3TABLES_BUCKET_NAME = os.getenv('S3TABLES_BUCKET_NAME')
AWS_ACCOUNT_ID = os.getenv('AWS_ACCOUNT_ID')
AWS_REGION = os.getenv('AWS_REGION', 'ap-northeast-1')

def lambda_handler(event, context):
    try:
        # Load Iceberg catalog from S3
        catalog = load_catalog(
            "s3tablescatalog",
            **{
                "type": "rest",
                "uri": f"https://glue.{AWS_REGION}.amazonaws.com/iceberg",
                "warehouse": f"{AWS_ACCOUNT_ID}:s3tablescatalog/{S3TABLES_BUCKET_NAME}",
                "rest.sigv4-enabled": "true",
                "rest.signing-name": "glue",
                "rest.signing-region": AWS_REGION,
            }
        )
        
        # Get Tables
        tables = catalog.list_tables("keiba_data")
        logger.info(f"Tables in the catalog: {tables}")
    except Exception as e:
        logger.error(f"Error loading Iceberg catalog: {e}")
        raise